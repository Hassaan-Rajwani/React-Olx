import './App.css';
import Router from './components/config/router';

function App() {
  return (
    <div className="">
      <Router />
    </div>
  )
}

export default App;