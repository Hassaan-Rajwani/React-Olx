import React from 'react';

export default function backimage() {
    return (
        <div>
            <img width={'100%'} src={"https://clone-frontpage-olx.netlify.app/back.JPG"} alt="" />
        </div>
    )
}
